use libc::{c_ulong, ioctl, winsize, STDERR_FILENO, STDIN_FILENO, STDOUT_FILENO};
use std::{io::Write, mem::zeroed, thread, time::{self, Duration}};
use rand::Rng;


fn main() {
    clear_screen();
    set_cursor_position(1, 1);


    let (mut w,  mut h) = dimensions().expect("Unable to get term size");

    // If you don't remove some padding then the cube is rendered outside the terminal size
    w -= 2;
    h -= 2;


    let mut loop_var = 0;
    while loop_var < 30 {
        set_cursor_position(loop_var, loop_var);
        print!("\x1b[{}m  \x1b[0m", ((loop_var % 8) + 40));
        loop_var += 1;
        std::io::stdout().flush().unwrap();


    }

    sleep(time::Duration::from_secs(5));

    clear_screen();
    set_cursor_position(1, 1);
    println!("Width: {}\nHeight: {}", w, h);
    sleep(time::Duration::from_secs(2));
 
}


fn clear_screen() {
    print!("{}[2J", 27 as char);
    std::io::stdout().flush().unwrap();
}

fn set_cursor_position(mut x: u16, y: u16) {
    x = (x * 2) - 1; 
    print!("{esc}[{y};{x}H", esc = 27 as char);
}

fn draw_red_cube() {
    print!("\x1b[41m  \x1b[0m");
    std::io::stdout().flush().unwrap();
}

fn draw_green_cube() {
    print!("\x1b[42m  \x1b[0m");
    std::io::stdout().flush().unwrap();
}







// Get window size stuff

static TIOCGWINSZ: c_ulong = 0x5413;


unsafe fn get_dimensions_any() -> winsize {
    let mut window: winsize = zeroed();
    let mut result = ioctl(STDOUT_FILENO, TIOCGWINSZ, &mut window);

    if result == -1 {
        window = zeroed();
        result = ioctl(STDIN_FILENO, TIOCGWINSZ, &mut window);
        if result == -1 {
            window = zeroed();
            result = ioctl(STDERR_FILENO, TIOCGWINSZ, &mut window);
            if result == -1 {
                return zeroed();
            }
        }
    }
    window
}



pub fn dimensions() -> Option<(u16, u16)> {
    let w = unsafe { get_dimensions_any() };

    if w.ws_col == 0 || w.ws_row == 0 {
        None
    } else {
        Some((w.ws_col as u16, w.ws_row as u16))
    }
}

pub fn sleep(dur: Duration) {
    std::io::stdout().flush().unwrap();
    let ten_millis = time::Duration::from_millis(10);
    let now = time::Instant::now();

    thread::sleep(dur);

    assert!(now.elapsed() >= ten_millis);
}

fn generate_apple() {
    let mut w: u16 = 0;
    let mut h: u16 = 0;
    (w, h) = dimensions().expect("Unable to get term size");
    w -= 2;
    h -= 2;
    let rand_x = rand::thread_rng().gen_range(1..=w);
    let rand_y = rand::thread_rng().gen_range(1..=h);
    set_cursor_position(rand_x, rand_y);
    draw_green_cube();
}


// fn main() {
//     let mut i = 0;
//     while i < 1000 {
//         println!("{}: {}", i, (i % 10) + 40);
//         i += 1;
//     }
// }